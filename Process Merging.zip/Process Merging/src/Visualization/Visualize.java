package Visualization;;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import org.w3c.dom.NodeList;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.plaf.basic.BasicMenuBarUI;

public class Visualize extends JFrame
  {

    public JSplitPane splitPaneV, splitPaneH, splitPaneH1;
    public static JPanel panel1, panel2, panel3, panel4;
    public JButton button1= new JButton( "Input IOBP " );
    public JButton button2= new JButton( "Output Integrated IOBP" );
    public static JScrollPane scrollPane;
    public static JTree NodeCounts,ProcessStructure;
    public static DefaultMutableTreeNode root = new DefaultMutableTreeNode("Element Count");
    public static DefaultMutableTreeNode rootNode=new DefaultMutableTreeNode("Process");
    public static File InputIOBP, OutputIOBP;
    public static NodeList ArtifactList,ActivityCount,GatewayCount,StateCount;

    public void AddPanelsToTextArea()
      {
        super.setBackground( Color.gray );
        super.setJMenuBar(addMenu());
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        super.add(topPanel);
       
        // Create the panels
        createPanels();

        // Create a splitter pane
        splitPaneV = new JSplitPane( JSplitPane.VERTICAL_SPLIT );
        topPanel.add( splitPaneV, BorderLayout.CENTER );
        splitPaneH = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT );
        splitPaneH.setLeftComponent( panel1 );
        splitPaneV.setLeftComponent( splitPaneH );
        splitPaneH1 = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT );
        splitPaneH1.setLeftComponent( panel2 );
        splitPaneH1.setRightComponent(new JSplitPane( JSplitPane.VERTICAL_SPLIT, panel3, panel4));
        splitPaneV.setRightComponent( splitPaneH1 );
      }
        
    public static JMenuBar addMenu()
      {
        JMenuBar menuBar=new JMenuBar();
        menuBar.setUI ( new BasicMenuBarUI (){
        public void paint ( Graphics g, JComponent c ){
        g.setColor (Color.cyan);
        g.fillRect ( 0, 0, c.getWidth (), c.getHeight () );
            }
        } );
        JMenu fileMenu=new JMenu("File");
        JMenu ViewMenu=new JMenu("View");
        JMenu closeMenu=new JMenu("Close");
        JMenu OpenMenuItem= new JMenu("Open");
        JMenu SaveMenuItem= new JMenu("Save");
        JMenuItem XMLMenuItem= new JMenuItem("XML");
        JMenuItem ExitMenuItem=new JMenuItem("Exit");
        XMLMenuItem.addActionListener(new ActionListener()
          {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                InputIOBP=GetFile();
                CountNodesandDisplayInput(InputIOBP); 
                panel3.removeAll();
                panel3.setVisible(true);
                panel3.revalidate();
                panel3.repaint();
             }  
          });
         
         fileMenu.add(OpenMenuItem);
         fileMenu.add(SaveMenuItem);
         
         ExitMenuItem.addActionListener(new ActionListener()
           {
            @Override
            public void actionPerformed(ActionEvent event) 
             {
                System.exit(0);
             }
          });
          fileMenu.add(ExitMenuItem);
          menuBar.add(fileMenu);
          menuBar.add(ViewMenu);
          menuBar.add(closeMenu);
          return menuBar;
      }

    public void createPanels()
      {
        //create Panel1
        panel1 = new JPanel();
        panel1.setBackground(Color.red);
        panel1.setLayout( new BorderLayout() );
        button1.setBackground(Color.pink);
        button2.setBackground(Color.pink);
        panel1.add( button1, BorderLayout.WEST );
        panel1.add( button2, BorderLayout.CENTER );
       

        //create Panel2
        panel2 = new JPanel();
        panel2.setLayout( new BorderLayout() );
        panel2.setBackground(Color.white);
        panel2.add(new TextArea(70,20),BorderLayout.NORTH);
        panel2.add(new TextArea(70,20),BorderLayout.SOUTH);

        //create Panel3
        panel3 = new JPanel();
        panel3.setLayout( new BorderLayout());
        panel3.setBackground(Color.white);
        panel3.add(new TextArea(70,20),BorderLayout.NORTH);
        panel3.add(new TextArea(70,20),BorderLayout.SOUTH);
             
        //create Panel4
        panel4=new JPanel();
        panel4.setLayout(new BorderLayout());
        panel4.setBackground(Color.white);

        //Add actionlisterners to buttons
        button1.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent e)
            {
                InputIOBP=GetFile();
                CountNodesandDisplayInput(InputIOBP);
               
    }
         });
        button2.addActionListener(new ActionListener()
         {
           public void actionPerformed(ActionEvent e)
            {
              if(InputIOBP!=null)
                {
                  
                  OutputIOBP=GetFile();
                  CountNodesandDisplayOutput(OutputIOBP);
                 

                }
              else
                {
                  JOptionPane.showMessageDialog(null, "Please browse/open an input file from File menu");
                }
            }
         });
      }
    
    public static File GetFile()
      {
        JFileChooser jFileChooser = new JFileChooser();
        jFileChooser.setCurrentDirectory(new File("C:\\Merge"));
        int result = jFileChooser.showOpenDialog(new JFrame());
        if (result == JFileChooser.APPROVE_OPTION) 
          {
            InputIOBP = jFileChooser.getSelectedFile();
          }
          return InputIOBP;
      }
        
    public static void CountNodesandDisplayInput(File selectedFile)
      {
        NodeCounts= new JTree(InputProcessStructure.CountProcessNodes(root,selectedFile));
        final Font currentFont = NodeCounts.getFont();
        final Font bigFont = new Font(currentFont.getName(), currentFont.getStyle(), currentFont.getSize() + 5);
        NodeCounts.setFont(bigFont);
        panel4.removeAll();
        scrollPane=new JScrollPane(NodeCounts);
        panel4.add(scrollPane);
        panel4.setVisible(true);
        panel4.revalidate();
        panel4.repaint();
        ProcessStructure = new JTree(InputProcessStructure.ProcessNodeswithArtifacts(rootNode, selectedFile));
        final Font currentFont1 = ProcessStructure.getFont();
        final Font bigFont1 = new Font(currentFont1.getName(), currentFont1.getStyle(), currentFont1.getSize() + 5);
        ProcessStructure.setFont(bigFont1);
        JScrollPane sp = new JScrollPane(ProcessStructure);
        sp.setPreferredSize(panel2.getSize());
        panel2.removeAll();
        panel2.add(BorderLayout.NORTH, sp);;
        panel2.setVisible(true);
        panel2.revalidate();
        panel2.repaint();
      }
    
    public static void CountNodesandDisplayOutput(File selectedFile)
      {
        NodeCounts= new JTree(OutputProcessStructure.CountProcessNodes(root,selectedFile));
        final Font currentFont = NodeCounts.getFont();
        final Font bigFont = new Font(currentFont.getName(), currentFont.getStyle(), currentFont.getSize() + 5);
        NodeCounts.setFont(bigFont);
        panel4.removeAll();
        scrollPane=new JScrollPane(NodeCounts);
        panel4.add(scrollPane);
        panel4.setVisible(true);
        panel4.revalidate();
        panel4.repaint();
        ProcessStructure = new JTree(OutputProcessStructure.ProcessNodeswithArtifacts(rootNode, selectedFile));
        final Font currentFont1 = ProcessStructure.getFont();
        final Font bigFont1 = new Font(currentFont1.getName(), currentFont1.getStyle(), currentFont1.getSize() + 5);
        ProcessStructure.setFont(bigFont1);
        JScrollPane sp = new JScrollPane(ProcessStructure);
        sp.setPreferredSize(panel3.getSize());
        panel3.removeAll();
        panel3.add(BorderLayout.NORTH, sp);;
        panel3.setVisible(true);
        panel3.revalidate();
        panel3.repaint();
      }
        
    public static void main( String args[] )
     {
        Visualize mainFrame = new Visualize();
        mainFrame.AddPanelsToTextArea();
        mainFrame.setTitle("Process Merging Tool");
        mainFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        mainFrame.setVisible(true);
      }
  }
