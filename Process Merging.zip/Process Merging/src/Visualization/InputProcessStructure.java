package Visualization;

import java.io.File;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class InputProcessStructure
  {
    public static Document doc;
    public static NodeList ArtifactList,ActivityList,GatewayList,StateList;
    public static DefaultMutableTreeNode CountProcessNodes(DefaultMutableTreeNode root,File selectedFile)
      {
        try                                                          
          {
            File fXmlFile = selectedFile;
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(fXmlFile);
            ArtifactList=doc.getElementsByTagName("object");
            ActivityList=doc.getElementsByTagName("task");
            GatewayList=doc.getElementsByTagName("gateway");
          }
        
        catch(Exception e) 
          {
            e.printStackTrace();
          }
          root.removeAllChildren();
           
          String artifactcount="The number of Artifacts:"+ArtifactList.getLength();
          String activitycount="The number of Activity Nodes:"+ActivityList.getLength();
          String gatewaycount="The number of Gateway Nodes:"+GatewayList.getLength();
         
          //create tree child nodes
          DefaultMutableTreeNode artifactcounttreenode = new DefaultMutableTreeNode(artifactcount);
          DefaultMutableTreeNode activitycounttreenode = new DefaultMutableTreeNode(activitycount);
          DefaultMutableTreeNode gatewaycounttreenode= new DefaultMutableTreeNode(gatewaycount);
        
          
          //add child nodes to the root node
          root.add(artifactcounttreenode );
          root.add(activitycounttreenode);
          root.add(gatewaycounttreenode );
          return root;
      }
        
    public static DefaultMutableTreeNode ProcessNodeswithArtifacts(DefaultMutableTreeNode rootNode, File selectedFile)
      {
        ArtifactList=doc.getElementsByTagName("object");
        Node root1=doc.getDocumentElement();
        NodeList RootChildList=root1.getChildNodes();
        for(int i=0;i<RootChildList.getLength();i++)
          {
            Node ProcessNode=RootChildList.item(i);
            if(ProcessNode.getNodeType()==Node.ELEMENT_NODE)
              { 
                if(ProcessNode.getNodeName().equalsIgnoreCase("CollaboratingProcesses"))
                  {
                    rootNode = new DefaultMutableTreeNode("Inter-Organizational Business Process");
                    for(int j=0;j<ProcessNode.getChildNodes().getLength();j++)
                      {
                        Node Process = ProcessNode.getChildNodes().item(j);
                        if(Process.getNodeType()==Node.ELEMENT_NODE)
                         { 
                           DefaultMutableTreeNode process = new DefaultMutableTreeNode(Process.getAttributes().getNamedItem("name").getNodeValue()+"-"+"process");
                           NodeList ProcessNodeList=Process.getChildNodes();
                           DisplayIOArtifacts(process,ProcessNodeList);
                           rootNode.add(process);
                         }
                      }
                  }
              }
          }
          return rootNode;
      }
    
    public static void DisplayIOArtifacts(DefaultMutableTreeNode rootNode,NodeList ChildList)
      {
        for(int i=0;i<ChildList.getLength();i++)
          {
            Node ChildNode=ChildList.item(i);
            if(ChildNode.getNodeType()==Node.ELEMENT_NODE)
              {
                String node=ChildNode.getNodeName();
                   
                if(node.equalsIgnoreCase("startEvent"))
                  {
                    DefaultMutableTreeNode startNode = new DefaultMutableTreeNode("Start");
                    rootNode.add(startNode);
                  }
                else if(node.equalsIgnoreCase("endEvent"))
                  {
                    DefaultMutableTreeNode endNode = new DefaultMutableTreeNode("End");
                    rootNode.add(endNode);
                  }
                else if(node.equalsIgnoreCase("task")||node.equalsIgnoreCase("gateway"))
                  {
                    DefaultMutableTreeNode child = new DefaultMutableTreeNode(ChildNode.getAttributes().getNamedItem("name").getNodeValue());
                    rootNode.add(child);
                    if(ChildNode.hasChildNodes())
                     {
                       DisplayIOArtifacts(child,ChildNode.getChildNodes());
                     }
                  }
                else if(node.equalsIgnoreCase("branch"))
                  {
                    DefaultMutableTreeNode child = new DefaultMutableTreeNode(ChildNode.getNodeName());
                    rootNode.add(child);
                    if(ChildNode.hasChildNodes())
                     {
                       DisplayIOArtifacts(child,ChildNode.getChildNodes());
                     }
                  }
               
                else if(node.equalsIgnoreCase("inputobject")||node.equalsIgnoreCase("outputobject"))
                  {
                    DefaultMutableTreeNode subchild = new DefaultMutableTreeNode(node);
                    rootNode.add(subchild);
                    if(ChildNode.hasAttributes())
                     {
                       String id=ChildNode.getAttributes().getNamedItem("id").getNodeValue();
                       node=getArtifact(id);
                       node=node+":"+ChildNode.getAttributes().getNamedItem("state").getNodeValue();
                       DefaultMutableTreeNode state = new DefaultMutableTreeNode(node);
                       subchild.add(state);
                     }
                    if(ChildNode.hasChildNodes())
                     {
                       DisplayIOArtifacts(subchild,ChildNode.getChildNodes());
                     }
                  }
                
                else if(node.equalsIgnoreCase("messageflows"))
                  {
                    DefaultMutableTreeNode subchild = new DefaultMutableTreeNode(node);
                    rootNode.add(subchild);
                    if(ChildNode.hasChildNodes())
                     {
                       DisplayIOArtifacts(subchild,ChildNode.getChildNodes());
                     }
                  }
              }
          }
      }
    
    public static String getArtifact(String id)
      {
        String art=null;
        for(int i=0;i<ArtifactList.getLength();i++)
         {
           Node artifact=ArtifactList.item(i);
           if(artifact.getNodeType()==Node.ELEMENT_NODE&&artifact.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(id))
             {
               art=artifact.getAttributes().getNamedItem("name").getNodeValue();
             }
         }
        return art;
     }
  }
