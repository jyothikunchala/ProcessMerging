package Merging;

import Merging.InteractiveMerge;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.NamedNodeMap;

public class ProcessMerging
  {
    public static ArrayList<String> arr= new ArrayList<>();
    public static ArrayList<String> array=new ArrayList<>();
    public static List<String> StList=new ArrayList<>();
    public static String xmlFilePath = "C:\\Merge\\IntegratedIOBP.xml";
    public static NodeList ObjList, processList;
    public static Element processdefinition;
    public static Node process=null,sender=null,receiver=null,returnnode=null, next=null, main=null,collab=null;
    public static Node process1=null;
    public static Node process2=null;
    public static Document document;
    public static String p_id,nodename=null,ntype=null,ctype=null,Itype=null,IntType=null, MergeType=null;
    public static int m=1,g=1,nodeindex=0,msgcount=0;
    public static ArrayList<String> MSG_Array=new ArrayList<>();
    
    public static void main(String argv[]) {
    try 
      {
 	File fXmlFile = new File("C:\\Merge\\BuyerSellerIOBP.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
        document = dBuilder.newDocument();
        ObjList=doc.getDocumentElement().getElementsByTagName("object");
        document = dBuilder.newDocument();
        Element root = document.createElement("IntegratedProcess");
        document.appendChild(root);
        System.out.println();
        
        Element objects = document.createElement("Objects");
        root.appendChild(objects);
        System.out.println();
       
        
        for(int i=0;i<ObjList.getLength();i++)
          {
            Node object=ObjList.item(i);
            if(object.getNodeType()==Node.ELEMENT_NODE)
              {
                Element obj=document.createElement(object.getNodeName());
                objects.appendChild(obj);
                if(object.hasAttributes())
                 {
                    NamedNodeMap AtList=object.getAttributes();
                    for (int j=0;j<AtList.getLength();j++)
                      {
                        Attr a=(Attr) AtList.item(j);
                        Attr a1=document.createAttribute(a.getName());
                        a1.setNodeValue(a.getValue());
                        obj.setAttributeNode(a1);
                      }
                  }
              }
          }
        processdefinition = document.createElement("ProcessDefinition");
        root.appendChild(processdefinition);
        processList=doc.getDocumentElement().getElementsByTagName("process");
        
       //Identify the main and collaborating processes
        for(int i=0;i<processList.getLength();i++)
          {
            if(processList.item(i).getNodeType()==Node.ELEMENT_NODE)
              {
                NodeList childList=processList.item(i).getChildNodes();
                for(int j=0;j<=childList.getLength()-2;j++)
                  {
                    if(childList.item(j).getNodeType()==Node.ELEMENT_NODE&&childList.item(j).hasChildNodes())
                       {
                          NodeList subChildList=childList.item(j).getChildNodes();
                          for(int y=0;y<subChildList.getLength();y++)
                             {
                               Node child=subChildList.item(y);
                               if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("messageflows"))
                                  {
                                    if(m==1&&child.getFirstChild().getNextSibling().getNodeName().equalsIgnoreCase("mout"))
                                      {
                                        process1=processList.item(i); //main process
                                        m=m+1;
                                      }                                         
                                    else if (g==1&&child.getFirstChild().getNextSibling().getNodeName().equalsIgnoreCase("min"))
                                       {
                              /*Change 2: new if*/  if(child.getFirstChild().getNextSibling().getAttributes().getNamedItem("p_id").getNodeValue().equalsIgnoreCase(process1.getAttributes().getNamedItem("p_id").getNodeValue()))
                                            {
                                               process2=processList.item(i); //collaborating process
                                               g=g+1;
                                             } 
                                        }
                                  }
                             }
                          }
                       }
                  }
              }
        
         Merge(process1.getFirstChild(), process2.getFirstChild(), processdefinition);
        
         //Create an instance of the test application
         TransformerFactory transformerFactory = TransformerFactory.newInstance();
         Transformer transformer = transformerFactory.newTransformer();
         DOMSource domSource = new DOMSource(document);
         StreamResult streamResult = new StreamResult(new File(xmlFilePath));
         transformer.transform(domSource, streamResult);
         System.out.println();
         System.out.println("Done creating XML File");
      }          
    
    catch(Exception e) 
      {
        e.printStackTrace();
      }
    }
    
   //Algorithm 1 
    public static void Merge(Node n, Node c, Element processdefinition)
     {
       Element parsplit=document.createElement("gateway");
       parsplit.setAttribute("name", "andsplit");
       if(n!=null &&c!=null)
        {
         if(n.getNodeType()!=Node.ELEMENT_NODE&&n.getNextSibling()!=null)
           {
             n=n.getNextSibling();
           }
         if(c.getNodeType()!=Node.ELEMENT_NODE&&c.getNextSibling()!=null)
           {
             c=c.getNextSibling();
           }
         if(n.getNodeName().equalsIgnoreCase("startevent")&&c.getNodeName().equalsIgnoreCase("startevent"))
           {
             Element child=document.createElement(n.getNodeName());
             processdefinition.appendChild(child); 
             if(n.hasAttributes())
               {
                createElt(n,child);
               }
             if(n.getNextSibling()!=null&&c.getNextSibling()!=null)
               {
                 Merge(n.getNextSibling(),c.getNextSibling(), processdefinition);
               }
            }
        else if(n.getNodeName().equalsIgnoreCase("endevent")&&c.getNodeName().equalsIgnoreCase("endevent"))
          {
            Element child=document.createElement(n.getNodeName());
            processdefinition.appendChild(child); 
            if(n.hasAttributes())
              {
                createElt(n,child);
              }
          }
        else if(n.getNodeName().equalsIgnoreCase("task")&&c.getNodeName().equalsIgnoreCase("task"))
          {
            ntype=TestInteraction(n);
            ctype=TestInteraction(c);
            if(ntype.equalsIgnoreCase("sync")&&ctype.equalsIgnoreCase("sync"))
              {
                InteractiveMerge.MergeSyncNodes(n, c, processdefinition);   
              }
            else
              {
                ParallelMerge.MergeNonSyncNodes(n,c,parsplit,processdefinition); 
              }
          }
       else
         {
           if(n.getNodeName().equalsIgnoreCase("gateway") && c.getNodeName().equalsIgnoreCase("gateway"))
              {
                ntype="nonsync";               
                ctype="nonsync";
                ParallelMerge.MergeNonSyncNodes(n, c, parsplit, processdefinition); 
              }
           else if(n.getNodeName().equalsIgnoreCase("gateway")&&c.getNodeName().equalsIgnoreCase("task"))
              {
                ntype="nonsync";
                ctype=TestInteraction(c);
                ParallelMerge.MergeNonSyncNodes(n, c, parsplit, processdefinition);
              }
           else if(n.getNodeName().equalsIgnoreCase("task")&&c.getNodeName().equalsIgnoreCase("gateway"))
              {
                ntype=TestInteraction(n);
                ctype="nonsync";
                ParallelMerge.MergeNonSyncNodes(n, c , parsplit, processdefinition);
              }
          }
       }
    }
     
    public static String TestInteraction(Node k)
      {
        Itype=null;
        NodeList childList=k.getChildNodes();
        for(int j=0;j<childList.getLength();j++)
          {
            Node child=childList.item(j);
            if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("messageflows"))
              {
                Itype="sync";
              }
          }
          if(Itype==null)
           {
             Itype="nonsync";
           }
         return Itype;
      }
               
  public static void createElt(Node n,Element e)
    {
      if(n.hasAttributes())
        {
          addAttributes(e,n);
        }
        if(n.hasChildNodes())
          {
            NodeList sub=n.getChildNodes();
            for(int i=0;i<sub.getLength();i++)
              {
                Node sn=sub.item(i);
                if(sn.getNodeType()==Node.ELEMENT_NODE&&!sn.getNodeName().equalsIgnoreCase("messageflows"))
                  {
                    Element ch=document.createElement(sn.getNodeName());
                    e.appendChild(ch);
                    createElt(sn,ch);
                  }
              }
          }
      }
  
  public static void AddInputObjects(Node n,Element e)
    {
        if(n.hasChildNodes())
          {
            NodeList sub=n.getChildNodes();
            for(int i=0;i<sub.getLength();i++)
              {
                Node sn=sub.item(i);
                if(sn.getNodeType()==Node.ELEMENT_NODE&&sn.getNodeName().equalsIgnoreCase("inputobject"))
                  {
                    Element ch=document.createElement(sn.getNodeName());
                    e.appendChild(ch);
                    createElt(sn,ch);
                  }
              }
          }
      }
  
  public static void AddOutputObjects(Node n,Element e)
    {
        if(n.hasChildNodes())
          {
            NodeList sub=n.getChildNodes();
            for(int i=0;i<sub.getLength();i++)
              {
                Node sn=sub.item(i);
                if(sn.getNodeType()==Node.ELEMENT_NODE&&sn.getNodeName().equalsIgnoreCase("outputobject"))
                  {
                    Element ch=document.createElement(sn.getNodeName());
                    e.appendChild(ch);
                    createElt(sn,ch);
                  }
              }
          }
      }
    public static void addAttributes(Element ch1,Node n)
      {
        if(n.hasAttributes())
          {
           NamedNodeMap AtList=n.getAttributes();
            for (int j=0;j<AtList.getLength();j++)
             {
               Attr a=(Attr) AtList.item(j);
               Attr a1=document.createAttribute(a.getName());
               a1.setNodeValue(a.getValue());
               ch1.setAttributeNode(a1);
             }
          }
      }
   }
   
           
       



  




