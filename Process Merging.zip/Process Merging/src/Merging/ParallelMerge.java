/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Merging;

import static Merging.ProcessMerging.Merge;
import static Merging.ProcessMerging.createElt;
import static Merging.ProcessMerging.Itype;
import static Merging.ProcessMerging.next;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import static Merging.ProcessMerging.ctype;
import static Merging.ProcessMerging.document;
import static Merging.ProcessMerging.next;
import static Merging.ProcessMerging.ntype;

/**
 *
 * @author kjyothi
 */
public class ParallelMerge {
    
    
//Algorithm 2
    public static void MergeNonSyncNodes(Node n, Node c, Element parsplit,Element processdefinition)
      {
        parsplit=document.createElement("gateway");
        parsplit.setAttribute("name", "andsplit");
        Element branch1=document.createElement("branch");
        parsplit.appendChild(branch1);
        Element branch2=document.createElement("branch");
        parsplit.appendChild(branch2);
        Element parmerge=document.createElement("gateway");
        parmerge.setAttribute("name", "andmerge");
        if(!ntype.equalsIgnoreCase("sync") && !ctype.equalsIgnoreCase("sync"))
          {
            Element child1=document.createElement(n.getNodeName());
            branch1.appendChild(child1);
            if(n.hasAttributes()||n.hasChildNodes())
              {
                createElt(n,child1);
              }
              n=MergeNextNodes(n,branch1);
              Element child2=document.createElement(c.getNodeName());
              branch2.appendChild(child2);
              if(c.hasAttributes()||c.hasChildNodes())
               {
                 createElt(c,child2);
               }
               c=MergeNextNodes(c,branch2);
               parsplit.appendChild(parmerge);
               processdefinition.appendChild(parsplit);
               if(n!=null)
                 {
                    n=n.getNextSibling();
                 }
                if(c!=null)
                 {
                   c=c.getNextSibling();
                 }
                 Merge(n,c, processdefinition);
            }
        else if(!ntype.equalsIgnoreCase("sync") && ctype.equalsIgnoreCase("sync"))
          {
            Element child1=document.createElement(n.getNodeName());
            branch1.appendChild(child1);
            createElt(n,child1);
            n=MergeNextNodes(n,branch1);
            branch2.appendChild(parmerge);
            processdefinition.appendChild(parsplit);
            Merge(n,c, processdefinition);
          }
        else if(ntype.equalsIgnoreCase("sync") && !ctype.equalsIgnoreCase("sync")) 
          {
            branch1.appendChild(parmerge);
            Element child2=document.createElement(c.getNodeName());
            branch2.appendChild(child2);
            if(c.hasAttributes()||c.hasChildNodes())
             {
               createElt(c,child2);
             } 
             c=MergeNextNodes(c,branch2);
             processdefinition.appendChild(parsplit);
             c=c.getNextSibling();
             Merge(n,c, processdefinition);
           }
       }
    
    //MergeNextNodes of nonsync nodess
    public static Node MergeNextNodes(Node k, Element branch)
      {
        if(k!=null)
         {
           if(k.getNodeType()!=Node.ELEMENT_NODE)
             {
               k=k.getNextSibling();
             }
            Itype= TestInteraction(k);
            if(!Itype.equalsIgnoreCase("sync"))
             {
               next=k.getNextSibling();
               while(next!=null&&next.getNodeType()!=Node.ELEMENT_NODE)
                 {
                   next=next.getNextSibling();
                   if(next!=null&&next.getNodeName().equalsIgnoreCase("task"))
                   {    
                     while(!Itype.equalsIgnoreCase("sync")&&!next.getNodeName().equalsIgnoreCase("endEvent"))
                      {
                        Element child=document.createElement(next.getNodeName());
                        branch.appendChild(child);
                        createElt(k,child);
                        k=MergeNextNodes(next, branch);
                      }
                   }
             else if(next!=null&&next.getNodeName().equalsIgnoreCase("gateway"))
              {
                Itype= "nonsync";
                if(k!=null)
                 {
                   k=AppendGatewayNodes(next, branch);
                 }
              }
           }
         }
       }
       return k;
     }
           
  public static Node AppendGatewayNodes(Node next, Element br)
    {
      Element gateway=document.createElement(next.getNodeName());
      gateway.setAttribute("name", next.getAttributes().getNamedItem("name").getNodeValue());
      NodeList childList=next.getChildNodes();
      for(int i=0;i<childList.getLength();i++)
        {
          Node child=childList.item(i);
          if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("branch"))
            {
              Element branch = document.createElement(child.getNodeName());
              gateway.appendChild(branch);
              for(int j=0;j<child.getChildNodes().getLength();j++)
                {
                  Node brchild=child.getChildNodes().item(j);
                  if(brchild.getNodeType()==Node.ELEMENT_NODE)
                    {
                      if(brchild.getNodeName().equalsIgnoreCase("task"))
                        {
                           Element task=document.createElement(brchild.getNodeName());
                           branch.appendChild(task);
                           createElt(brchild,task);
                        }
                      else if(brchild.getNodeName().equalsIgnoreCase("gateway"))
                        {
                          Itype= "nonsync";
                          next=AppendGatewayNodes(brchild, br);
                        }
                    }
                }
            }
         }
        return next;
      }
    public static String TestInteraction(Node k)
      {
        Itype=null;
        NodeList childList=k.getChildNodes();
        for(int j=0;j<childList.getLength();j++)
         {
           Node child=childList.item(j);
           if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("messageflows"))
             {
               Itype="sync";
             }
         }
         if(Itype==null)
           {
             Itype="nonsync";
           }
          return Itype;
      }
}
               
 