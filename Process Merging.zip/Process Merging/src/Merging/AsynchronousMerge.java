/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Merging;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Attr;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import static Merging.ProcessMerging.Merge;
import static Merging.ProcessMerging.ctype;
import static Merging.ProcessMerging.document;
import static Merging.ProcessMerging.ntype;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.sender;
import static Merging.ProcessMerging.AddInputObjects;
import static Merging.ProcessMerging.AddOutputObjects;
import static Merging.ProcessMerging.MergeType;
import static Merging.ProcessMerging.Merge;
import static Merging.ProcessMerging.addAttributes;
import static Merging.ProcessMerging.createElt;
import static Merging.ProcessMerging.document;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.sender;
/**
 *
 * @author kjyothi
 */
public class AsynchronousMerge {
    
   //Algorithm 5
    public static void AsynchronousMerge(Node n, Node c, Element processdefinition)
     {
       if(MergeType.equalsIgnoreCase("NonSplit"))
       {
         Element child1=document.createElement(n.getNodeName());
         Element child2=document.createElement(c.getNodeName());
         if(sender==n&&receiver==c)
           {
             processdefinition.appendChild(child1);
             child1.setAttribute("name", n.getAttributes().getNamedItem("name").getNodeValue());
             if(n.hasChildNodes())
              {
                AddInputObjects(n,child1);
              }
              processdefinition.appendChild(child2);
              if(c.hasAttributes()||c.hasChildNodes())
               {
                 createElt(c,child2); //To add both attributes and childnodes
               }
           }
         else
           {
             processdefinition.appendChild(child2);
             child2.setAttribute("name", c.getAttributes().getNamedItem("name").getNodeValue());
             if(c.hasChildNodes())
              {
                AddInputObjects(c,child2);
              }
              processdefinition.appendChild(child1);
              if(n.hasAttributes()||n.hasChildNodes())
               {
                 createElt(n,child1);
               }
           }
        }
      
       else if (MergeType.equalsIgnoreCase("Split"))
         {
          Element gatewaysplit=document.createElement("gateway");
          gatewaysplit.setAttribute("name", "andsplit");
          Element gatewaymerge=document.createElement("gateway");
          gatewaymerge.setAttribute("name", "andmerge");
          Element branch1=document.createElement("branch");
          Element branch2=document.createElement("branch");
          gatewaysplit.appendChild(branch1);
          gatewaysplit.appendChild(branch2);
          if(sender==n&&receiver==c)
            {
              Element child1=document.createElement(n.getNodeName());
              child1.setAttribute("name", n.getAttributes().getNamedItem("name").getNodeValue());
              if(n.hasChildNodes())
                {
                  AddInputObjects(n,child1);
                }
                branch1.appendChild(child1);
                Element child2pre=document.createElement(c.getNodeName());
                if(c.hasAttributes())
                  {
                    String name=c.getAttributes().getNamedItem("name").getNodeValue();
                    name="Pre_"+name;
                    Attr a1=document.createAttribute("name");
                    a1.setNodeValue(name);
                    child2pre.setAttributeNode(a1);
                   }
                  Element child2post=document.createElement(c.getNodeName());
                  if(c.hasAttributes())
                    {
                      String name=c.getAttributes().getNamedItem("name").getNodeValue();
                      name="Post_"+name;
                      Attr a1=document.createAttribute("name");
                      a1.setNodeValue(name);
                      child2post.setAttributeNode(a1);
                    }
                  if(c.hasChildNodes())
                    {
                      TestandAnnotateIO(n,c,child2pre, child2post);
                    }
                    branch2.appendChild(child2pre);
                    gatewaysplit.appendChild(gatewaymerge);
                    processdefinition.appendChild(gatewaysplit);
                    if(c.hasChildNodes())
                      {
                        AddOutputObjects(c,child2post);
                      }
                      processdefinition.appendChild(child2post);
            }
        else if(sender==c&&receiver==n)
          {
            Element child1=document.createElement(c.getNodeName());
            child1.setAttribute("name", c.getAttributes().getNamedItem("name").getNodeValue());
            if(c.hasChildNodes())
              {
                AddInputObjects(c,child1);
              }
              branch1.appendChild(child1);
              Element child2pre=document.createElement(n.getNodeName());
              if(n.hasAttributes())
                {
                  String name=n.getAttributes().getNamedItem("name").getNodeValue();
                  name="Pre_"+name;
                  Attr a1=document.createAttribute("name");
                  a1.setNodeValue(name);
                  child2pre.setAttributeNode(a1);
                }
              Element child2post=document.createElement(n.getNodeName());
              if(n.hasAttributes())
                {
                  String name=n.getAttributes().getNamedItem("name").getNodeValue();
                  name="Post_"+name;
                  Attr a1=document.createAttribute("name");
                  a1.setNodeValue(name);
                  child2post.setAttributeNode(a1);
                }
              if(n.hasChildNodes())
                {
                  TestandAnnotateIO(n,c,child2pre,child2post);
                }
                branch2.appendChild(child2pre);
                gatewaysplit.appendChild(gatewaymerge);
                processdefinition.appendChild(gatewaysplit);
                if(n.hasChildNodes())
                  {
                    AddOutputObjects(n,child2post);
                  }
                  processdefinition.appendChild(child2post);
          }
        }
        
        if(n.getNextSibling()!=null&&c.getNextSibling()!=null)
          {
            Merge(n.getNextSibling(),c.getNextSibling(), processdefinition);
          }
     }
    
    public static void AsynchronousNonSplitMerge(Node n, Node c, Element child1,Element child2,Element processdefinition)
      {
       if(sender==n&&receiver==c)
          {
            processdefinition.appendChild(child1);
            processdefinition.appendChild(child2);
          }
        else
          {
            processdefinition.appendChild(child2);
            processdefinition.appendChild(child1);
          }
          
          if(n.getNextSibling()!=null&&c.getNextSibling()!=null)
           {
             Merge(n.getNextSibling(),c.getNextSibling(), processdefinition);
           }
      }
    
    public static void AsynchronousSplitMerge(Node n, Node c, Element child1,Element child2,Element processdefinition)
      {
       if(sender==n&&receiver==c)
        {
          processdefinition.appendChild(child1);
          processdefinition.appendChild(child2);
        }
        else
        {
          processdefinition.appendChild(child2);
          processdefinition.appendChild(child1);
        }
        if(n.getNextSibling()!=null&&c.getNextSibling()!=null)
         {
           Merge(n.getNextSibling(),c.getNextSibling(), processdefinition);
         }
      }
      
    public static void TestandAnnotateIO(Node sender,Node receiver,Element splitnodePre, Element splitnodePost)
        {
         String match=null;
         if(receiver.hasChildNodes())
          {
           for(int i=0;i<receiver.getChildNodes().getLength();i++)
             {
              Node rchild=receiver.getChildNodes().item(i);
              if(rchild.getNodeType()==Node.ELEMENT_NODE&&rchild.getNodeName().equalsIgnoreCase("inputobject"))
                 {
                    Element inputobject1=document.createElement(rchild.getNodeName()); 
                    Element inputobject2=document.createElement(rchild.getNodeName());
                    if(rchild.hasChildNodes())
                      {
                        for(int m=0;m<rchild.getChildNodes().getLength();m++)
                          {
                            Node msubchild=rchild.getChildNodes().item(m);
                            if(msubchild.getNodeType()==Node.ELEMENT_NODE)
                              {
                                if(msubchild.hasAttributes())
                                   {
                                     String rid=msubchild.getAttributes().getNamedItem("id").getNodeValue();
                                     String rstate=msubchild.getAttributes().getNamedItem("state").getNodeValue();
                                     for(int j=0;j<sender.getChildNodes().getLength();j++)
                                       {
                                         Node schild=sender.getChildNodes().item(j);
                                         if(schild.getNodeType()==Node.ELEMENT_NODE&&schild.getNodeName().equalsIgnoreCase("messageflows"))
                                           {
                                             if(schild.hasChildNodes())
                                               {
                                                for(int k=0;k<schild.getChildNodes().getLength();k++)
                                                  {
                                                    Node ssubchild=schild.getChildNodes().item(k);
                                                    if(ssubchild.getNodeType()==Node.ELEMENT_NODE&&ssubchild.getNodeName().equalsIgnoreCase("mout"))
                                                      {
                                                       if(ssubchild.hasAttributes())
                                                          {
                                                            String sid=ssubchild.getAttributes().getNamedItem("id").getNodeValue();
                                                            String sstate=ssubchild.getAttributes().getNamedItem("state").getNodeValue();
                                                            if(!rid.equalsIgnoreCase(sid)||!rstate.equalsIgnoreCase(sstate))
                                                              {
                                                                Element obj=document.createElement(ssubchild.getNodeName());
                                                                addAttributes(obj,ssubchild);
                                                                inputobject1.appendChild(obj);
                                                              }
                                                            else if(rid.equalsIgnoreCase(sid)&&rstate.equalsIgnoreCase(sstate))
                                                             {
                                                                Element obj=document.createElement(ssubchild.getNodeName());
                                                                addAttributes(obj,ssubchild);
                                                                inputobject2.appendChild(obj);
                                                                
                                                             }
                                                          }
                                                      }
                                                    }
                                                }
                                            }
                                        }
                                    }
                              }
                          }
                        if(inputobject1.hasChildNodes())
                          {
                            splitnodePre.appendChild(inputobject1);
                          }
                         if(inputobject2.hasChildNodes())
                          {
                            splitnodePost.appendChild(inputobject2);
                          }
                     }
                    else if(rchild.hasAttributes())
                      {
                        Element inputobject=document.createElement(rchild.getNodeName());
                        addAttributes(inputobject,rchild);
                        splitnodePost.appendChild(inputobject);
                     }
                 }
             }
          }
       }
   }
   
           
       



  





    

