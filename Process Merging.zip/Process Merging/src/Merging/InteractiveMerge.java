/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Merging;

import static Merging.ProcessMerging.IntType;
import static Merging.ProcessMerging.process1;
import static Merging.ProcessMerging.process2;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.sender;
import static Merging.ProcessMerging.returnnode;
import static Merging.ProcessMerging.Merge;
import static Merging.ProcessMerging.document;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.returnnode;
import static Merging.ProcessMerging.sender;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import static Merging.AsynchronousMerge.AsynchronousMerge;
import static Merging.ProcessMerging.createElt;
import static Merging.ProcessMerging.ctype;
import static Merging.ProcessMerging.ntype;
import static Merging.ProcessMerging.processdefinition;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.sender;
import static Merging.SynchronousMerge.FindReturningNode;
import static Merging.SynchronousMerge.SynchronousMerge;
import static Merging.ProcessMerging.MergeType;

/**
 *
 * @author kjyothi
 */
public class InteractiveMerge {
    
    //Algorithm3
    public static void MergeSyncNodes(Node n, Node c, Element processdefinition)
      {
        IntType=CheckInteractionType(n, c);
        if(IntType.equalsIgnoreCase("Synchronous"))
          {
            SynchronousMerge(n, c, processdefinition);
          }
        else if(IntType.equalsIgnoreCase("Asynchronous"))
          {
            AsynchronousMerge(n, c, processdefinition);
          }
      }
 
    public static String CheckInteractionType(Node n, Node c)
     {
       sender=null;
       receiver=null;
       IntType= null;
       for(int i=0;i<n.getChildNodes().getLength();i++)
        {
          Node child=n.getChildNodes().item(i);
          if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("messageflows"))
            {
              Node message=child.getFirstChild();
              if(message!=null&&message.getNodeType()!=Node.ELEMENT_NODE)
               {
                  message=message.getNextSibling();
               }
               Node mnext=message.getNextSibling();
               if(mnext!=null&&mnext.getNodeType()!=Node.ELEMENT_NODE)
                 {
                    mnext=mnext.getNextSibling();
                 }
               if(message!=null)
                 {
                if(message.getNodeName().equalsIgnoreCase("mout")&&message.getAttributes().getNamedItem("p_id").getNodeValue().equalsIgnoreCase(process2.getAttributes().getNamedItem("p_id").getNodeValue()))
                  {
                    if(mnext!=null)
                     {
                       if(mnext.getNodeName().equalsIgnoreCase("min")&&mnext.getAttributes().getNamedItem("p_id").getNodeValue().equalsIgnoreCase(process2.getAttributes().getNamedItem("p_id").getNodeValue()))
                        {
                          IntType = "Synchronous";
                          sender = n;
                          receiver = c;
                          returnnode = FindReturningNode(c, message, process1);
                          MergeType=TestMergeType(sender);
                        }
                     }
                    else if(mnext==null)
                      {
                        IntType="Asynchronous";
                        sender=n;
                        receiver=c;
                        MergeType=TestMergeType(receiver);
                      }
                   }
            
                else if(message.getNodeName().equalsIgnoreCase("min")&&message.getAttributes().getNamedItem("p_id").getNodeValue().equalsIgnoreCase(process2.getAttributes().getNamedItem("p_id").getNodeValue()))
                   {
                     if(mnext!=null)
                      {
                        if(mnext.getNodeName().equalsIgnoreCase("mout")&&mnext.getAttributes().getNamedItem("p_id").getNodeValue().equalsIgnoreCase(process2.getAttributes().getNamedItem("p_id").getNodeValue()))
                         {
                           IntType="Synchronous";
                           receiver=n;
                           sender=c;
                           returnnode = FindReturningNode(n, mnext, process2);
                           MergeType=TestMergeType(sender);
                         }
                      }
                     else if(mnext==null)
                      {
                        IntType="Asynchronous";
                        receiver=n;
                        sender=c;
                        MergeType=TestMergeType(receiver);
                      }
                   }
               }
            }
        }
      return IntType;
    }
    
    public static String TestMergeType(Node snode)
      {
        MergeType=null;
        Node outputobject=null, message=null;
        for(int i=0;i<snode.getChildNodes().getLength();i++)
          {
            Node child=snode.getChildNodes().item(i);
            if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("outputobject"))
              {
                if(child.getNodeName().equalsIgnoreCase("outputobject"))
                  {
                    outputobject=child;
                  }
              }
            if(child.getNodeName().equalsIgnoreCase("messageflows"))
              {
                for(int j=0;j<child.getChildNodes().getLength();j++)
                  {
                  if(child.getChildNodes().item(j).getNodeType()==Node.ELEMENT_NODE&&child.getChildNodes().item(j).getNodeName().equalsIgnoreCase("min"))
                    {
                      message=child.getChildNodes().item(j);
                    }
                  }
              }
          }
         if(outputobject==null)
          {
             MergeType="NonSplit";
          }
         else 
           {
            if(outputobject.hasChildNodes())
              {
               for(int g=0;g<outputobject.getChildNodes().getLength();g++)
                 {
                   Node subchild=outputobject.getChildNodes().item(g);
                   if(subchild.getNodeType()==Node.ELEMENT_NODE)
                     {
                       String OutputObjectID=subchild.getAttributes().getNamedItem("id").getNodeValue();
                       String OutputObjectState=subchild.getAttributes().getNamedItem("state").getNodeValue();
                       for(int mc=0;mc<message.getChildNodes().getLength();mc++)
                         {
                           Node submessage=message.getChildNodes().item(mc);
                           if(submessage.getNodeType()==Node.ELEMENT_NODE)
                            {
                              MergeType=null;
                              String MessageObjectID=submessage.getAttributes().getNamedItem("id").getNodeValue();
                              String MessageObjectState=submessage.getAttributes().getNamedItem("state").getNodeValue();
                              if(OutputObjectID.equalsIgnoreCase(MessageObjectID)&&OutputObjectState.equalsIgnoreCase(MessageObjectState))
                                {
                                  MergeType="NonSplit";
                                }
                            }
                         }
                     }
                 }
                 if(MergeType==null)
                   {
                     MergeType="Split";
                   }
            }
          else if(outputobject.hasAttributes())
            {
              if(message.hasAttributes())
                {
                  String OutputObjectID=outputobject.getAttributes().getNamedItem("id").getNodeValue();
                  String MessageObjectID=message.getAttributes().getNamedItem("id").getNodeValue();
                  String OutputObjectState=outputobject.getAttributes().getNamedItem("state").getNodeValue();
                  String MessageObjectState=message.getAttributes().getNamedItem("state").getNodeValue();
                  if(OutputObjectID.equalsIgnoreCase(MessageObjectID)&&OutputObjectState.equalsIgnoreCase(MessageObjectState))
                    {
                      MergeType="NonSplit";
                    }
                }
                if(MergeType==null)
                  {
                    MergeType="Split";
                  }
              }
          }
          return MergeType;
      }
}
  
  