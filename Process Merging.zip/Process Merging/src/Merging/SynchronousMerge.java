/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Merging;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import static Merging.ProcessMerging.Merge;
import static Merging.ProcessMerging.document;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.returnnode;
import static Merging.ProcessMerging.sender;
import static Merging.ProcessMerging.AddInputObjects;
import static Merging.ProcessMerging.AddOutputObjects;
import static Merging.ProcessMerging.MergeType;
import static Merging.ProcessMerging.Merge;
import static Merging.ProcessMerging.createElt;
import static Merging.ProcessMerging.document;
import static Merging.ProcessMerging.receiver;
import static Merging.ProcessMerging.returnnode;
import static Merging.ProcessMerging.sender;

/**
 *
 * @author kjyothi
 */
public class SynchronousMerge 
  {
    //Algorithm 4 
    public static void SynchronousMerge(Node n, Node c, Element processdefinition)
     {
       if(MergeType.equalsIgnoreCase("NonSplit"))
        {
          SynchronousNonSplitMerge(n, c, processdefinition);
        }
       else if(MergeType.equalsIgnoreCase("Split"))
        {
          SynchronousSplitMerge(n, c, processdefinition);
        }
     }
    
    public static void SynchronousNonSplitMerge(Node n, Node c, Element processdefinition)
      {
      if(MergeType.equalsIgnoreCase("NonSplit"))
        {
          Element child1=document.createElement(n.getNodeName());
          if(n.hasAttributes())
           {
             Attr a1=document.createAttribute("name");
             a1.setNodeValue(n.getAttributes().getNamedItem("name").getNodeValue());
             child1.setAttributeNode(a1);
           }
           if(n.hasChildNodes())
             {
               AddInputObjects(n,child1);
             }
           Element child2=document.createElement(c.getNodeName());
           if(c.hasAttributes()||c.hasChildNodes())
            {
              createElt(c,child2);
            }
           if(sender==n&&receiver==c)
             {
               processdefinition.appendChild(child1);
               processdefinition.appendChild(child2);
               if(returnnode!=c)
                {
                  c=AddUntilReturn(c,processdefinition);
                }
             }
           else if(sender==c&&receiver==n)
             {
               processdefinition.appendChild(child2);
               processdefinition.appendChild(child1);
               if(returnnode!=n)
                {
                  n=AddUntilReturn(n,processdefinition);
                }
             }
             Merge(n.getNextSibling(),c.getNextSibling(), processdefinition);
        }
     }
   
    public static void SynchronousSplitMerge(Node n, Node c, Element processdefinition)
     {
       if(sender==n&&receiver==c)
        {
          Element child1pre=document.createElement(n.getNodeName());
          if(n.hasAttributes())
           {
             String name=n.getAttributes().getNamedItem("name").getNodeValue();
             name="Pre_"+name;
             Attr a1=document.createAttribute("name");
             a1.setNodeValue(name);
             child1pre.setAttributeNode(a1);
           }
           if(n.hasChildNodes())
            {
              AddInputObjects(n,child1pre);
            }
            Element child2=document.createElement(c.getNodeName());
            child2.setAttribute("name", c.getAttributes().getNamedItem("name").getNodeValue());
            if(c.hasChildNodes())
             {
               AddInputObjects(n,child2);
             }
            if(returnnode!=c)
             {
               c=AddUntilReturn(c,processdefinition);
             }
             Element child1post=document.createElement(n.getNodeName());
             if(n.hasAttributes())
              {
                String name=n.getAttributes().getNamedItem("name").getNodeValue();
                name="Post_"+name;
                Attr a1=document.createAttribute("name");
                a1.setNodeValue(name);
                child1post.setAttributeNode(a1);
              }
            if(n.hasChildNodes())
              {
                AddOutputObjects(n,child1post);
              }
              processdefinition.appendChild(child1pre);
              processdefinition.appendChild(child2);
              processdefinition.appendChild(child1post);
        }
       else if(sender==c&&receiver==n)
        {
          Element child1pre=document.createElement(c.getNodeName());
          if(c.hasAttributes())
            {
              String name=c.getAttributes().getNamedItem("name").getNodeValue();
              name="Pre_"+name;
              Attr a1=document.createAttribute("name");
              a1.setNodeValue(name);
              child1pre.setAttributeNode(a1);
            }
            if(c.hasChildNodes())
              {
                AddInputObjects(c,child1pre);
              }
            Element child2=document.createElement(n.getNodeName());
            child2.setAttribute("name", n.getAttributes().getNamedItem("name").getNodeValue());
            if(n.hasChildNodes())
             {
               AddInputObjects(n,child2);
             }
            if(returnnode!=n)
             {
              n=AddUntilReturn(n,processdefinition);
              }
            Element child1post=document.createElement(c.getNodeName());
            if(c.hasAttributes())
              {
                String name=c.getAttributes().getNamedItem("name").getNodeValue();
                name="Post_"+name;
                Attr a1=document.createAttribute("name");
                a1.setNodeValue(name);
                child1post.setAttributeNode(a1);
              }
            if(c.hasChildNodes())
              {
                AddOutputObjects(c,child1post);
              }
             processdefinition.appendChild(child1pre);
             processdefinition.appendChild(child2);
             processdefinition.appendChild(child1post);
        }
          Merge(n.getNextSibling(),c.getNextSibling(), processdefinition);
     }
    public static Node AddUntilReturn(Node r, Element processdefinition)
     {
       while(returnnode!=r)
        {
          Node cnext=r.getNextSibling();
          if(cnext!=null&&cnext.getNodeType()!=Node.ELEMENT_NODE)
           {
            cnext=cnext.getNextSibling();
           }
           Element childnext=document.createElement(cnext.getNodeName());
           if(cnext.hasAttributes()||cnext.hasChildNodes())
            {
             createElt(cnext,childnext);
            }
            processdefinition.appendChild(childnext);
            r=cnext;
        }
    return r;
  }

 public static Node FindReturningNode(Node r, Node min, Node P)
  {
    for(int i=0;i<r.getChildNodes().getLength();i++)
      {
        Node child=r.getChildNodes().item(i);
        if(child.getNodeType()==Node.ELEMENT_NODE&&child.getNodeName().equalsIgnoreCase("messageflows"))
         {
            Node message=child.getFirstChild();
            while(message!=null&&message.getNodeType()!=Node.ELEMENT_NODE)
              {
                message=message.getNextSibling();
                if(message.getNodeName().equalsIgnoreCase("mout")&&message.getAttributes().getNamedItem("p_id").getNodeValue().equalsIgnoreCase(P.getAttributes().getNamedItem("p_id").getNodeValue()))
                  {
                    if(message.hasChildNodes())
                      {
                        for(int b=0;b<message.getChildNodes().getLength();b++)
                          {
                            Node mchild=message.getChildNodes().item(b);
                            if(mchild.getNodeType()==Node.ELEMENT_NODE)
                             {
                              if(mchild.hasAttributes())
                               {
                                if(min.hasAttributes())
                                  {
                                    if(min.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(mchild.getAttributes().getNamedItem("id").getNodeValue()))
                                      {
                                        if(returnnode==null)
                                          {
                                            returnnode=r;
                                          }
                                      }
                                  }
                                else if(min.hasChildNodes())
                                  {
                                    for(int j=0;j<min.getChildNodes().getLength();j++)
                                     {
                                       Node minchild=min.getChildNodes().item(j);
                                       if(minchild.getNodeType()==Node.ELEMENT_NODE)
                                         {
                                           if(minchild.hasAttributes())
                                             {
                                               if(mchild.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(minchild.getAttributes().getNamedItem("id").getNodeValue()))
                                                 {
                                                   if(returnnode==null)
                                                    {
                                                      returnnode=r;
                                                    }
                                                 }
                                             }   
                                         }
                                     }
                                  }
                                }
                             }
                          }
                       }
                      else if(message.hasAttributes())
                       {
                         if(min.hasAttributes())
                           {
                            if(min.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(message.getAttributes().getNamedItem("id").getNodeValue()))
                              {
                                if(returnnode==null)
                                 {
                                   returnnode=r;
                                 }
                               }
                           }
                       else if(min.hasChildNodes())
                         {
                           for(int j=0;j<min.getChildNodes().getLength();j++)
                            {
                              Node minchild=min.getChildNodes().item(j);
                              if(minchild.getNodeType()==Node.ELEMENT_NODE)
                                {
                                 if(minchild.hasAttributes())
                                   {
                                    if(message.getAttributes().getNamedItem("id").getNodeValue().equalsIgnoreCase(minchild.getAttributes().getNamedItem("id").getNodeValue()))
                                      {
                                        if(returnnode==null)
                                          {
                                            returnnode=r;
                                          }
                                      }
                                   }
                                }
                            }
                          }
                       }
                  }
              }
         }
      }
    while(returnnode==null)
      {
        Node rnext=r.getNextSibling();
        if(rnext!=null&&rnext.getNodeType()!=Node.ELEMENT_NODE)
         {
           rnext=rnext.getNextSibling();
         }
        if(rnext!=null)
         {
           returnnode=FindReturningNode(rnext,min,P);
         }
         r=rnext;
        }
     return returnnode;
  }
}
    
  
